# LEO Design System

> **Status:** v0.1 — bootstrapped from a single logo asset. Visual direction is an inference from the supplied mark; refine with real product context.

---

## Brand overview

**LEO** is a technology brand inferred from its mark: a geometric, polygonal lion head inside a tilted diamond frame, rendered in glowing cyan over deep navy, surrounded by circuit-board traces. The visual DNA reads AI / cybersecurity / developer-tool — "intelligence at the edge."

Positioning (inferred, please confirm):
- Confident, technical, slightly cinematic
- Targets developers, platform / security engineers, and technical decision-makers
- Brand animal (lion) = strength, vigilance, leadership; paired with circuitry = machine intelligence

### Provided source material

| Source | Path | Notes |
|---|---|---|
| Logo (JPEG) | `uploads/leo.jpeg` → `assets/leo-logo.jpeg` | Cyan geometric lion in diamond frame over navy |

No codebase, Figma, decks, brand guidelines, product screenshots, or tagline were supplied. Everything below is a reasoned extrapolation from the single logo — **flag anything that conflicts with real LEO brand, and I'll rebuild.**

---

## Content fundamentals

Inferred voice — **confident, technical, a little cinematic**. LEO talks like a capable co-pilot, not a mascot.

| Axis | Direction | Example |
|---|---|---|
| Point of view | Second person ("you"), occasional first-person plural ("we") for product/company | "You ship. LEO watches." |
| Casing | **Sentence case** for UI and marketing body. **ALL CAPS** used only for eyebrows, stat labels, and the `LEO` wordmark. | `CORE CAPABILITIES` (eyebrow), "Core capabilities" (section title) |
| Tone | Declarative, short sentences. No hedging. No exclamation marks. | "Threats move fast. LEO moves first." |
| Tech register | Comfortable with technical nouns (SBOM, SSO, vectors, embeddings) — never dumbed down. | "Scoped API keys, OIDC, audit trails." |
| Emoji | **No.** Brand does not use emoji. | — |
| Jargon | Allowed when precise. Never decorative. | — |
| Punctuation | Em-dashes for emphasis. Periods on full sentences in body only; bulleted fragments skip the period. | — |
| Numbers | Numerals (1–9 OK as digits), display stats in mono or display font. | `99.99%`, `<50ms` |
| Wordmark | Always `LEO` in uppercase, never "Leo" or "leo". | — |

**Tagline patterns to mine from:**
- "See every signal." (observability)
- "Intelligence that defends itself." (security)
- "The autonomous layer for modern engineering." (platform)

---

## Visual foundations

**Signature move:** glowing cyan linework over deep navy, with optional circuit-trace textures as ambient background.

### Color
- **Brand color is a single cyan family** — `--leo-cyan-300` (`#6FE3FF`) for glow/stroke, `--leo-cyan-400` (`#4ECBFF`) for primary interactive.
- **Neutrals are navies, not grays.** Every "gray" is a cool blue-black (`--leo-navy-*`) so the palette stays cohesive with the logo.
- **One secondary accent** (`--leo-magenta #C66BFF`) used sparingly for data viz / second series only. Never decorative.
- **Status colors** are saturated-but-muted (`--leo-success #3AE6B0`, `--leo-warning #FFCE5C`, `--leo-danger #FF5E87`) so they coexist with cyan without clashing.
- Dark-first. A light mode is not defined in v0.1.

### Type
- **Display:** Orbitron — geometric, techy, matches the logo's `LEO` wordmark. Used for H1/H2, eyebrows, big numerals, the wordmark.
- **Sans / body:** Space Grotesk — wide apertures, tech-feeling but readable at body size.
- **Mono:** JetBrains Mono — code, versions, stats, IDs.
- Tracking is **tight on display** (`-0.01em`), **wide on eyebrows** (`+0.22em uppercase`).

### Backgrounds
- Deep navy (`#070C1A`) is the canonical page background.
- Ambient **circuit-trace SVG** (`assets/circuit-bg.svg`) used faintly (opacity ~0.35) behind hero sections — never repeating in body.
- **Radial cyan glow spots** behind the hero, painted with `radial-gradient(ellipse at ..., rgba(78,203,255,0.15), transparent 60%)`.
- **No gradients as fills** on UI surfaces — only as ambient glow behind content.
- Never use purple→blue gradients (AI-slop trope). Cyan stays cyan.

### Borders, shadows, glow
- Hairline borders are **cyan-tinted at low opacity** (`rgba(111,227,255,0.14)`) — they read like faint neon trim, not gray divider lines.
- Drop shadows are dark-on-dark (`rgba(0,0,0,0.45)`) plus a hairline border combined into `--leo-shadow-2`.
- The **glow** tokens (`--leo-glow-sm/md/lg`) are the brand's primary "elevation" signal — applied on focus, hover of primary CTAs, and the logo mark itself.

### Corner radii
- Cards: `--leo-radius-lg` (16px)
- Inputs/buttons: `--leo-radius-md` (10px)
- Tags/chips: `--leo-radius-pill` (999px)
- Diamond frames around the mark: no radius — sharp corners reference the logo.

### Cards
- `background: var(--leo-surface)` (`#0E1830`)
- `border: 1px solid var(--leo-border)` (cyan hairline)
- `border-radius: 16px`
- Hover: border becomes `--leo-border-2`, adds `--leo-glow-sm`

### Motion
- **Fast, decisive easing:** `cubic-bezier(0.22, 1, 0.36, 1)` for exits, `cubic-bezier(0.65, 0, 0.35, 1)` for symmetric motion.
- No bounces. No 3D flips. No spring overshoots.
- Durations: 120ms (micro), 220ms (standard), 420ms (hero entrance).
- Fades + subtle Y translation (4–8px) for entrance. Opacity + glow pulse for attention.

### Hover / press
- **Hover:** raise border opacity, add `--leo-glow-sm`, color shifts up one step (`cyan-400 → cyan-300`).
- **Press:** scale `0.98`, glow drops to `none`, color deepens to `cyan-500`.
- **Focus:** 2px `outline-offset` ring in `--leo-cyan-400` plus `--leo-glow-md`.

### Transparency / blur
- Sparingly. Navigation bar uses `backdrop-filter: blur(12px)` with `rgba(7,12,26,0.7)` when scrolled.
- Overlays/modals use a `rgba(4,7,15,0.72)` scrim with `blur(6px)`.

### Imagery
- Cool palette, cyan accents, often synthetic / diagrammatic (wireframes, isometric product UI, data visualizations) rather than stock photography.
- If photography: low-key lighting, cyan color grading, subtle grain.

### Layout rules
- Grid-based with generous vertical rhythm (`--leo-space-7/8` between sections).
- Max content width: 1200px, narrowed to 960px for text.
- Hero uses the full viewport with ambient background, then content relaxes into contained grids.

---

## Iconography

**Approach:** line icons, 1.5px stroke, rounded caps, no fills — matches the polygonal/linework of the lion mark. Cyan on default, never multicolor.

No proprietary icon system was supplied, so we **substitute [Lucide](https://lucide.dev)** — clean, open-source, matches the stroke style. Icons are pulled via CDN (`https://cdn.jsdelivr.net/npm/lucide@latest`) or inlined as SVG.

- **Emoji:** not used.
- **Unicode glyphs:** allowed only for math/arrows when semantically precise (`→`, `↗`, `·`).
- **Custom marks:** the LEO lion (`assets/leo-mark.svg`) and wordmark (`assets/leo-wordmark.svg`) are the only brand-specific marks. Do not redraw.

**Flag:** please confirm icon direction. If LEO has a real icon set, drop it in `assets/icons/` and I'll swap.

---

## Fonts

All three families are Google Fonts; no local files needed. They're loaded via `@import` at the top of `colors_and_type.css`.

- **Orbitron** — display (H1/H2, eyebrows, `LEO` wordmark, stat numerals)
- **Space Grotesk** — body, H3/H4, UI
- **JetBrains Mono** — code, versions, technical metadata

**Flag:** these are substitutions chosen to match the logo's geometric feel. If you have licensed brand fonts, drop them in `fonts/` and update `colors_and_type.css`.

---

## Index

```
LEO Design System/
├── README.md                   ← you are here
├── SKILL.md                    ← agent-skill manifest
├── colors_and_type.css         ← tokens (import this first)
├── assets/
│   ├── leo-logo.jpeg           ← original supplied logo
│   ├── leo-mark.svg            ← isolated geometric lion mark
│   ├── leo-wordmark.svg        ← "LEO" wordmark
│   └── circuit-bg.svg          ← ambient circuit-trace background
├── preview/                    ← design-system cards (rendered in the DS tab)
│   ├── colors-brand.html
│   ├── colors-neutral.html
│   ├── colors-semantic.html
│   ├── type-display.html
│   ├── type-body.html
│   ├── type-mono.html
│   ├── spacing.html
│   ├── radii.html
│   ├── shadows-glow.html
│   ├── buttons.html
│   ├── inputs.html
│   ├── cards.html
│   ├── badges.html
│   └── logo.html
└── ui_kits/
    └── website/
        ├── README.md
        ├── index.html          ← landing page
        └── components/*.jsx
```

**Start here when designing for LEO:**
1. Import `colors_and_type.css`.
2. Wrap your root in a `.leo-scope` class so typography + colors apply.
3. Use tokens (`var(--leo-cyan-300)`) — don't hard-code hexes.
4. Pull components from `ui_kits/website/` as reference.

---

## Caveats (v0.1)

- **Inferred from a single JPEG logo.** No product context, no tagline, no user research. Treat every copy choice as placeholder.
- **Fonts are Google-Fonts substitutions** (Orbitron / Space Grotesk / JetBrains Mono). Swap if LEO has licensed brand fonts.
- **Icons are Lucide** (substitution). Swap if LEO has a proprietary set.
- **No light mode** defined. Can add if needed.
- **One product surface** (marketing website). No app UI, docs, or email templates yet.
