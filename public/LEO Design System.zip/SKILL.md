---
name: leo-design
description: Use this skill to generate well-branded interfaces and assets for LEO, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick reference

- **Brand color:** cyan `#4ECBFF` (primary interactive), `#6FE3FF` (glow stroke). Dark-first, navy `#070C1A` backgrounds.
- **Type:** Orbitron (display), Space Grotesk (body), JetBrains Mono (code). Google Fonts.
- **Signature move:** glowing cyan linework over deep navy + ambient circuit traces. Never purple→blue gradients.
- **Assets:** `assets/leo-mark.svg`, `assets/leo-wordmark.svg`, `assets/circuit-bg.svg`, plus the original logo jpeg.
- **Tokens:** import `colors_and_type.css`, wrap root in `.leo-scope`.
- **UI kit:** `ui_kits/website/` has a full landing page with reusable JSX components (Nav, Hero, FeatureGrid, CodeShowcase, StatsBand, CTA, Footer).
